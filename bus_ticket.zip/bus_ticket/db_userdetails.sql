-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2022 at 06:24 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_userdetails`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(11) NOT NULL,
  `adminName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adminPhone` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adminUser` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adminPassword` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `adminName`, `adminPhone`, `adminUser`, `adminPassword`) VALUES
(1, 'Thacksin', '2092196964', 'admin', '025863'),
(2, 'Phoudthavong', '2092145332', 'admin2', '123456'),
(6, 'Bunsy', '789456123', 'bunsy', '7894');

-- --------------------------------------------------------

--
-- Table structure for table `tb_booking`
--

CREATE TABLE `tb_booking` (
  `bookID` int(11) NOT NULL,
  `bookUser` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `departDate` date NOT NULL,
  `busNO` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seat` int(11) NOT NULL,
  `paid` int(11) NOT NULL,
  `ticketID` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Fname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Lname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_booking`
--

INSERT INTO `tb_booking` (`bookID`, `bookUser`, `departDate`, `busNO`, `seat`, `paid`, `ticketID`, `Fname`, `Lname`) VALUES
(1, 'user1', '2022-02-26', 'ບຂ 0778', 12, 3000, '023456', 'Thaksin', 'Thongkham'),
(2, 'user1', '2022-02-26', 'ບຂ 0778', 11, 3000, '1234', 'Jimmy', 'Carter'),
(3, 'user1', '2022-02-26', 'ກກ 6003', 3, 300000, '7894', 'Boss', 'Derr'),
(4, 'user1', '2022-02-26', 'ກກ 6003', 21, 300000, '2123', 'dwr', 'qwre'),
(5, 'user1', '2022-02-27', 'ກຂ 0001', 1, 10000, '4321', 'erqw', '12qrw'),
(6, 'user1', '2022-02-27', 'ກຂ 0001', 2, 10000, '43221', 'ewq', 'qwer'),
(7, 'user1', '2022-02-26', 'ບຂ 0778', 24, 3000, '7865', 'er', 'ew'),
(8, 'user1', '2022-02-26', 'ກກ 6003', 10, 300000, '2314', 'eqrw', 'eqrw'),
(9, 'user1', '2022-02-26', 'ກກ 6003', 7, 300000, 'qwrqw', '4123', '12342'),
(10, 'boss', '2022-02-26', 'ບຂ 0778', 20, 3000, '43214', 'eqw', '432'),
(11, 'boss', '2022-02-28', 'ກຍ 4166', 5, 1000, '431232', 'Boeing', 'Derr'),
(12, 'admin1', '2022-02-26', 'ກກ 6003', 6, 300000, '034267', 'Bigbank', 'Khn d'),
(13, 'bpss', '2022-02-26', 'ບຂ 0778', 22, 3000, '1234123', 'Phisitsai', 'Thongkham'),
(14, 'boss', '2022-02-26', 'ບຂ 0778', 19, 3000, 're213', 'Thim', 'Jay'),
(15, 'admin1', '2022-02-13', 'ອບ 1111', 4, 12000, 'PQ2132', 'Thinnakone', 'Thongkham'),
(16, 'boss', '2022-03-31', 'ບກ 0065', 13, 120000, 'ZX2148', 'Chanmany', 'Phomsena'),
(17, 'admin1', '2022-02-13', 'ອບ 1111', 3, 12000, 'ZN7845', 'ຄຳດີ', 'ສົມສຸກ'),
(18, 'admin1', '2022-02-13', 'ອບ 1111', 1, 12000, 'ZX7894', 'Chan', 'Many'),
(19, 'boss', '2022-02-26', 'ບຂ 0778', 15, 3000, 'CX78945', 'Thaksin', 'Thongkham');

-- --------------------------------------------------------

--
-- Table structure for table `tb_bus`
--

CREATE TABLE `tb_bus` (
  `busID` int(11) NOT NULL,
  `busNO` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `busProvince` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `busSource` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `busDest` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `busTime` time NOT NULL,
  `busDate` date NOT NULL,
  `busSeat` int(11) NOT NULL,
  `busPrice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_bus`
--

INSERT INTO `tb_bus` (`busID`, `busNO`, `busProvince`, `busSource`, `busDest`, `busTime`, `busDate`, `busSeat`, `busPrice`) VALUES
(1, 'ບຂ 0778', 'ກຳແພງນະຄອນ', 'ຂົວດິນ', 'ດົງຄຳຊ້າງ', '12:22:00', '2022-02-26', 20, 3000),
(4, 'ກກ 6003', 'ກຳແພງນະຄອນ', 'ວັດນາກ', 'ສີໄຄ', '07:00:00', '2022-02-26', 2, 300000),
(6, 'ກຍ 4166', 'ກຳແພງນະຄອນ', 'ຫາຍໂສກ', 'ໂພນຕ້ອງ', '08:45:00', '2022-02-28', 4, 1000),
(7, 'ບກ 0065', 'ກຳແພງນະຄອນ', 'ວັດນາກ', 'ໂພນໂຮງ', '21:00:00', '2022-03-31', 24, 120000),
(9, 'ອບ 1111', 'ກຳແພງນະຄອນ', 'ວັດນາກ', 'ສີໄຄ', '08:10:00', '2022-02-13', 2, 12000),
(10, 'ນນ 2139', 'ກຳແພງນະຄອນ', 'ວົງວຽນ', 'ຄຳສະຫວາດ', '12:45:00', '2022-03-02', 25, 5000),
(11, 'ລນ 3899', 'ກຳແພງນະຄອນ', 'ສີໂຄດຕະບອງ', 'ວັງວຽງ', '12:35:00', '2022-03-06', 25, 3000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_employee`
--

CREATE TABLE `tb_employee` (
  `epID` int(11) NOT NULL,
  `epFName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `epLName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `epGender` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `epBirthDay` date NOT NULL,
  `epRolls` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `epEmais` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `epPhone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_employee`
--

INSERT INTO `tb_employee` (`epID`, `epFName`, `epLName`, `epGender`, `epBirthDay`, `epRolls`, `epEmais`, `epPhone`) VALUES
(1, 'ທັກສິນ ', 'ທອງຄຳ', 'male', '2002-05-11', 'ຄົນຂັບລົດ', 'bg@mail.com', 123456789),
(2, 'ພິຊິດໄຊ', 'ທອງຄຳ', 'male', '2006-03-08', 'ຄົນຂັບລົດ', 'bb@mail.com', 258631248),
(3, 'ຈັນທະປັນຍາ', 'ສູນດາລາ', 'female', '2001-09-11', 'ຄົນຂາຍປີ້', 'tt@mail.com', 2585611),
(4, 'Buasoth', 'Phavanh', 'male', '1966-01-29', 'ຄົນອະນາໄມ', 'jk@mail.com', 7784561);

-- --------------------------------------------------------

--
-- Table structure for table `tb_userdetails`
--

CREATE TABLE `tb_userdetails` (
  `userID` int(11) NOT NULL,
  `userFName` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userLName` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userGender` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userAge` int(11) NOT NULL,
  `userPhoneNums` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userName` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userPassword` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_userdetails`
--

INSERT INTO `tb_userdetails` (`userID`, `userFName`, `userLName`, `userGender`, `userAge`, `userPhoneNums`, `userName`, `userPassword`) VALUES
(1, 'Thacksin', 'Thongkham', 'ຊາຍ', 18, '2059549549', 'Thaksin2002', 'Bigboss59549549'),
(4, 'Thinnakone', 'Thongkham', 'ຊາຍ', 53, '2055511861', 'TNK', '1234'),
(5, 'ສົມບັດ', 'ເລຍຢິເຮີ', 'ຊາຍ', 63, '2054558453', 'sombath', '762156'),
(6, 'bigboss', 'derr', 'ຊາຍ', 20, '2059549549', 'boss', '1234'),
(8, 'Phisitsai', 'Thongkham', 'ຊາຍ', 16, '2095090393', 'BBPSS', '123456'),
(9, 'ເກວະລິນ', 'ທອງຄຳ', 'ຍິງ', 26, '2077512998', 'kvl', '123456879'),
(10, 'Andrew', 'Garfield', 'ຊາຍ', 31, '2058456852', 'sad', '2021'),
(11, 'wqrqw', 'qwreqwrw', 'ຊາຍ', 18, '2314112', 'qwerty', 'qwerqwe'),
(12, 'golf', 'defi', 'ຊາຍ', 21, '2094515687', 'dulahan', '007'),
(13, 'Phoumano', 'Sundara', 'ຊາຍ', 53, '2055469069', 'phoumano', 'NONO1234'),
(14, 'jiep', 'sing', 'ຍິງ', 45, '2054215842', 'jiep', '7894'),
(15, 'ພິຊິດໄຊ', 'ທອງຄຳ', 'ຊາຍ', 16, '2095090393', 'bpss', 'Bigbank1234'),
(16, 'TNK', 'Thongkham', 'ຊາຍ', 45, '2055443322', 'tnk1', '21323');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_booking`
--
ALTER TABLE `tb_booking`
  ADD PRIMARY KEY (`bookID`);

--
-- Indexes for table `tb_bus`
--
ALTER TABLE `tb_bus`
  ADD PRIMARY KEY (`busID`);

--
-- Indexes for table `tb_employee`
--
ALTER TABLE `tb_employee`
  ADD PRIMARY KEY (`epID`);

--
-- Indexes for table `tb_userdetails`
--
ALTER TABLE `tb_userdetails`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `userName` (`userName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_booking`
--
ALTER TABLE `tb_booking`
  MODIFY `bookID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tb_bus`
--
ALTER TABLE `tb_bus`
  MODIFY `busID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tb_employee`
--
ALTER TABLE `tb_employee`
  MODIFY `epID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_userdetails`
--
ALTER TABLE `tb_userdetails`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
